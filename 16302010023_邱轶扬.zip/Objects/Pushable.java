package Objects;

public interface Pushable {

}
