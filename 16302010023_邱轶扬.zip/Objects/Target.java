package Objects;

public class Target extends MapObject {
    Target(){

    }

    Target(int x, int y){
        super(x, y);
    }
}
