package Objects;


public class Box extends MovableChecker implements Pushable {
    public Box(int x, int y) {
        super(x, y);
    }


}
