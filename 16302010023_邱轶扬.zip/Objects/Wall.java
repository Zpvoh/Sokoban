package Objects;

public class Wall extends MapObject {
    public Wall(int x, int y){
        super(x, y);
    }
}
